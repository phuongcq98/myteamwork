/**
 * 
 */
package vn.fpt.restaurant.manager.dao;

import java.util.List;

import vn.fpt.restaurant.manager.entities.CategoryDish;

/**
 * @author Admin
 *
 */
public interface CategoryDao {

	List<CategoryDish> list();

	void save(CategoryDish categoryDish);

	CategoryDish getCategoryDish(Long id);

	void update(CategoryDish categoryDish);

	void delete(CategoryDish categoryDish);

	boolean codeExist(String code);

	boolean checkDelete(Long id);

}
